﻿public enum OrderStatus
{
    Created,
    Paid,
    InProgress,
    Ready,
    Completed
}

public enum Volume
{
    S = 250,
    M = 350,
    L = 450
}
