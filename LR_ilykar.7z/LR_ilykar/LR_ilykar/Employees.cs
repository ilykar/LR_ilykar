﻿using System.Threading;
using System;

public abstract class Employee
{
    public string Name { get; }
    public int EmployeeId { get; }

    protected Employee(string name, int employeeId)
    {
        Name = name;
        EmployeeId = employeeId;
    }

    public abstract void DoWork(Order order);
}

public class Cashier : Employee
{
    public Cashier(string name, int employeeId) : base(name, employeeId) { }

    public override void DoWork(Order order)
    {
        Console.WriteLine($"\n# КАССИР {Name} начинает обработку заказа #{order.OrderId}");
        AcceptPayment(order);
    }

    private void AcceptPayment(Order order)
    {
        Console.WriteLine($"  Принята оплата: {order.TotalPrice:C}");
        order.UpdateStatus(OrderStatus.Paid);
        Console.WriteLine($"  Кассир {Name} передал заказ #{order.OrderId} бариста");
    }
}

public class Barista : Employee
{
    public Barista(string name, int employeeId) : base(name, employeeId) { }

    public override void DoWork(Order order)
    {
        Console.WriteLine($"\n# БАРИСТА {Name} начинает готовить заказ #{order.OrderId}");
        PrepareOrder(order);
    }

    private void PrepareOrder(Order order)
    {
        order.UpdateStatus(OrderStatus.InProgress);

        // Имитация процесса приготовления
        Console.WriteLine("  Приготовление напитков...");
        Thread.Sleep(1000);
        Console.WriteLine("  Добавление добавок...");
        Thread.Sleep(500);

        order.UpdateStatus(OrderStatus.Ready);
        Console.WriteLine($"  Бариста {Name} завершил приготовление заказа #{order.OrderId}");
    }
}
