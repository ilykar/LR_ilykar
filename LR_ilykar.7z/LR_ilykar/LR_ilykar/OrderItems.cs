﻿using System;
using System.Collections.Generic;
using System.Linq;

public class OrderItem
{
    public Product Product { get; }
    public int Quantity { get; }

    public OrderItem(Product product, int quantity)
    {
        Product = product;
        Quantity = quantity;
    }

    public decimal GetCost()
    {
        return Product.GetCost() * Quantity;
    }

    public string GetDescription()
    {
        return $"{Product.GetDescription()} x{Quantity} - {GetCost()} руб";
    }
}

// Order.cs
public class Order
{
    private static int _nextOrderId = 1;

    public int OrderId { get; }
    public OrderStatus Status { get; private set; }
    private List<OrderItem> Items { get; }
    public decimal TotalPrice => CalculateTotal();

    public Order()
    {
        OrderId = _nextOrderId++;
        Status = OrderStatus.Created;
        Items = new List<OrderItem>();
    }

    public void AddItem(Product product, int quantity = 1)
    {
        var existingItem = Items.FirstOrDefault(item => item.Product.GetDescription() == product.GetDescription());

        if (existingItem != null)
        {
            // В реальной системе здесь была бы логика обновления количества
            // Для простоты добавляем как новую позицию
            Items.Add(new OrderItem(product, quantity));
        }
        else
        {
            Items.Add(new OrderItem(product, quantity));
        }

        Console.WriteLine($"# Добавлено: {product.GetDescription()} x{quantity}");
    }

    public void RemoveItem(OrderItem item)
    {
        Items.Remove(item);
    }

    public decimal CalculateTotal()
    {
        return Items.Sum(item => item.GetCost());
    }

    public void UpdateStatus(OrderStatus newStatus)
    {
        Console.WriteLine($"# Статус заказа #{OrderId} изменен: {Status} → {newStatus}");
        Status = newStatus;
    }

    public void DisplayOrder()
    {
        Console.WriteLine($"\n# ЗАКАЗ #{OrderId} (Статус: {Status})");
        Console.WriteLine("=" + new string('=', 40));

        foreach (var item in Items)
        {
            Console.WriteLine($"  {item.GetDescription()}");
        }

        Console.WriteLine($"\n  ИТОГО: {TotalPrice:C}");
        Console.WriteLine("=" + new string('=', 40));
    }
}
