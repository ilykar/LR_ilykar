﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("# СИСТЕМА УПРАВЛЕНИЯ КОФЕЙНЕЙ");
        Console.WriteLine("=" + new string('=', 50));

        // Создаем сотрудников
        var cashier = new Cashier("Елизавета", 1);
        var barista = new Barista("Илья", 2);

        // Создаем продукты
        var espresso = new Beverage("Эспрессо", 100m, Volume.S);
        var cappuccino = new Beverage("Капучино", 150m, Volume.M);
        var tiramisu = new Dessert("Тирамису", 200m, false);
        var glutenFreeCake = new Dessert("Морковный торт", 180m, true);

        // Сценарий 1: Простой заказ эспрессо
        Console.WriteLine("\n# СЦЕНАРИЙ 1: Простой заказ");
        Console.WriteLine("-" + new string('-', 30));

        var order1 = new Order();
        order1.AddItem(espresso);
        order1.DisplayOrder();

        cashier.DoWork(order1);
        barista.DoWork(order1);
        order1.UpdateStatus(OrderStatus.Completed);

        // Сценарий 2: Сложный заказ с добавками
        Console.WriteLine("\n# СЦЕНАРИЙ 2: Сложный заказ с добавками");
        Console.WriteLine("-" + new string('-', 30));

        var order2 = new Order();

        // Создаем капучино с молоком и сиропом
        var cappuccinoWithAddons = new SyrupAddon(new MilkAddon(cappuccino));
        order2.AddItem(cappuccinoWithAddons);

        // Десерт без добавок
        order2.AddItem(tiramisu);

        // Еще один эспрессо с корицей
        var espressoWithCinnamon = new CinnamonAddon(espresso);
        order2.AddItem(espressoWithCinnamon, 2);

        order2.DisplayOrder();

        cashier.DoWork(order2);
        barista.DoWork(order2);
        order2.UpdateStatus(OrderStatus.Completed);

        // Сценарий 3: Заказ с безглютеновым десертом
        Console.WriteLine("\n# СЦЕНАРИЙ 3: Заказ для клиента с аллергией");
        Console.WriteLine("-" + new string('-', 30));

        var order3 = new Order();
        order3.AddItem(glutenFreeCake);
        order3.AddItem(new MilkAddon(espresso));

        order3.DisplayOrder();

        cashier.DoWork(order3);
        barista.DoWork(order3);
        order3.UpdateStatus(OrderStatus.Completed);

        Console.WriteLine($"\n# Все заказы завершены! Рабочий день окончен.");
        Console.ReadKey();
    }
}
