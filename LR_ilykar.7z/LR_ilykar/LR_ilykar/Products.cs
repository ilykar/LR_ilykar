﻿public abstract class Product
{
    public string Name { get; protected set; }
    public decimal BasePrice { get; protected set; }

    protected Product(string name, decimal basePrice)
    {
        Name = name;
        BasePrice = basePrice;
    }

    public virtual string GetDescription()
    {
        return Name;
    }

    public virtual decimal GetCost()
    {
        return BasePrice;
    }
}

public class Beverage : Product
{
    public Volume Volume { get; private set; }

    public Beverage(string name, decimal basePrice, Volume volume)
        : base(name, basePrice)
    {
        Volume = volume;
    }

    public override string GetDescription()
    {
        return $"{base.GetDescription()} ({Volume} - {(int)Volume}мл.)";
    }
}

public class Dessert : Product
{
    public bool IsGlutenFree { get; private set; }

    public Dessert(string name, decimal basePrice, bool isGlutenFree)
        : base(name, basePrice)
    {
        IsGlutenFree = isGlutenFree;
    }

    public override string GetDescription()
    {
        string glutenInfo = IsGlutenFree ? " (Без глютена)" : " (Содержит глютен)";
        return base.GetDescription() + glutenInfo;
    }
}
