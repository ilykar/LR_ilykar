﻿public abstract class Addon : Product
{
    protected Product Product { get; }

    protected Addon(Product product, string addonName, decimal addonPrice)
        : base(addonName, addonPrice)
    {
        Product = product;
    }
}

public class MilkAddon : Addon
{
    public MilkAddon(Product product)
        : base(product, "Молоко", 50m)
    {
    }

    public override string GetDescription()
    {
        return $"{Product.GetDescription()}, с молоком";
    }

    public override decimal GetCost()
    {
        return Product.GetCost() + BasePrice;
    }
}

public class SyrupAddon : Addon
{
    public SyrupAddon(Product product)
        : base(product, "Сироп", 30m)
    {
    }

    public override string GetDescription()
    {
        return $"{Product.GetDescription()}, с сиропом";
    }

    public override decimal GetCost()
    {
        return Product.GetCost() + BasePrice;
    }
}

public class CinnamonAddon : Addon
{
    public CinnamonAddon(Product product)
        : base(product, "Корица", 20m)
    {
    }

    public override string GetDescription()
    {
        return $"{Product.GetDescription()}, с корицей";
    }

    public override decimal GetCost()
    {
        return Product.GetCost() + BasePrice;
    }
}
